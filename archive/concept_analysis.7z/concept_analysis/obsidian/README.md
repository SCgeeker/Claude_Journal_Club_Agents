# 📊 Concept Mapper 分析結果索引

**生成時間**: 2025-11-05 16:54:39

**知識庫**: knowledge_base

---

## 📁 文件列表

### 核心文件

1. **[[suggested_links]]** - 建議新增的概念連結
   - 基於語義相似度的智能推薦
   - 包含關係類型和信度評分

2. **[[key_concepts_moc]]** - 關鍵概念地圖
   - Top 20 核心概念 (基於 PageRank)
   - Hub 節點和 Bridge 節點分析

3. **[[path_analysis]]** - 概念推導路徑
   - 有影響力的概念演化路徑
   - 幫助理解概念間的邏輯關係

### 社群摘要

- 📂 [[community_summaries/]] - 社群檢測結果
  - 檢測到 1 個概念社群
  - 每個社群對應一個摘要筆記

## 📊 統計摘要

- **節點數**: 704
- **邊數**: 56436
- **平均度**: 160.33
- **網絡密度**: 0.2281
- **社群數**: 1

### 關係類型分布

- `leads_to`: 14
- `contrasts_with`: 36438
- `related_to`: 15197
- `subclass_of`: 1840
- `superclass_of`: 2947

## 🚀 使用指南

1. 從 **key_concepts_moc** 開始，了解核心概念
2. 查看 **suggested_links**，補充連結到你的筆記
3. 瀏覽 **community_summaries**，理解知識結構
4. 探索 **path_analysis**，發現概念演化路徑

---

**工具**: [Concept Mapper](https://github.com/your-repo) Phase 2.2

---
title: PsychonomicBulletin&Review
authors: 
year: null
keywords: []
created: 2025-10-29 16:23:31
---

# PsychonomicBulletin&Review

## 基本信息

- **作者**: 
- **年份**: N/A
- **關鍵詞**: 

## 摘要

combinedbysyntacticrules(e.g.,Burgess&Lund,1997; symbols.Harnadconsidersapersonlandingatanairport
Chomsky, 1980; Fodor, 2000; Kintsch, 1988; Pinker, inaforeigncountry(perhapsChina)whoselanguageshe
1994).Wordsareabstractinthatthesameword,suchas does not speak. At her disposal is a dictionary written
“chair,”isusedforbigchairsandlittlechairs,wordsare solelyinthatlanguage.Upondisembarking,sheseesasign
amodal in that the same word is used when chairs are with a sentencein logograms, and she wishes to deter-
spokenaboutorwrittenabout,andwordsarearbitrarily minethemeaningofthesentence.Shelooksupthefirst
relatedtotheirreferentsinthatthephonemicandortho- logogram(anabstractsymbol)inthedictionary,onlyto
graphiccharacteristicsofawordbearnorelationshipto find that its definitionis given by its relationsto addi-
thephysicalorfunctionalcharacteristicsoftheword’sref- tionalabstractsymbols.Todeterminethemeaningofthe
erent. An alternativeview is that linguistic meaning is firstsymbolinthedefinition,shelooksitupinthedic-
groundedinbodilyactivity(e.g.,Barsalou,1999;Fincher- tionaryonlytobefacedwithadditionalabstractsymbols.
Kiefer, 2001;Glenberg, 1997;Glenberg & Robertson, Nomatterhowmanyoftheseabstractsymbolssherelates
1999, 2000;Lakoff, 1987; McNeill,1992;Stanfield & tooneanother,sheisnevergoingtodeterminethemean-
Zwaan, 2001).Here, we reporta new phenomenonthat ingofthesentence.Thelessonisthattheabstractsymbols
discriminatesbetweentheseapproaches.Wedemonstrate oflanguagemustbegrounded,ormapped,totheworldif
thatmerelycomprehendingasentencethatimpliesaction theyare to conveymeaning.Butthereare goodreasons
inonedirection(e.g.,“Closethedrawer”impliesaction forbelievingthatifonehasonlyabstractsymbolsatone’s
awayfromthebody)interfereswithrealactionintheop- disposal,determinationofthecorrectmappingisimpos-
positedirection(e.g.,movementtowardthebody).These sible(Lakoff,1987).
dataareconsistentwiththeclaimthatlanguagecompre- In contrasttomeaningasanabstractsymbolsystem,
hensionisgroundedin

## 研究背景

## 研究方法

## 主要結果

## 討論與結論

## 個人評論

## 相關文獻

## 完整內容

PsychonomicBulletin&Review
2002,9(3),558-565
Grounding language in action
ARTHURM.GLENBERGandMICHAELP.KASCHAK
UniversityofWisconsin,Madison,Wisconsin
Wereportanewphenomenon associatedwithlanguagecomprehension:theaction–sentencecom-
patibilityeffect(ACE).Participantsjudgedwhethersentencesweresensiblebymakingaresponsethat
requiredmovingtowardorawayfromtheirbodies.Whenasentenceimpliedactioninonedirection(e.g.,
“Closethedrawer”impliesactionawayfromthebody),theparticipantshaddifficultymakingasensi-
bilityjudgmentrequiringaresponseintheoppositedirection.TheACEwasdemonstratedforthreesen-
tencestypes:imperativesentences,sentencesdescribingthetransferofconcreteobjects,andsentences
describingthetransferofabstractentities,suchas“Liztoldyouthestory.”Thesedataareinconsistent
withtheoriesoflanguagecomprehensioninwhichmeaningisrepresentedasasetofrelationsamong
nodes.Instead,thedatasupportanembodiedtheoryofmeaningthatrelatesthemeaningofsentences
tohumanaction.
Howlanguageconveysmeaningremainsanopenques- appear to work as abstract symbols), Harnad’s (1990)
tion.Thedominantapproachistotreatlanguageasasym- versionofSearle’s(1980)“ChineseRoom”argumentpro-
bolmanipulationsystem:Languageconveysmeaningby videsacompellingintuitionastowhymeaningcannotbe
usingabstract,amodal,andarbitrarysymbols(i.e.,words) conveyedsolelybythesyntacticrelationsamongabstract
combinedbysyntacticrules(e.g.,Burgess&Lund,1997; symbols.Harnadconsidersapersonlandingatanairport
Chomsky, 1980; Fodor, 2000; Kintsch, 1988; Pinker, inaforeigncountry(perhapsChina)whoselanguageshe
1994).Wordsareabstractinthatthesameword,suchas does not speak. At her disposal is a dictionary written
“chair,”isusedforbigchairsandlittlechairs,wordsare solelyinthatlanguage.Upondisembarking,sheseesasign
amodal in that the same word is used when chairs are with a sentencein logograms, and she wishes to deter-
spokenaboutorwrittenabout,andwordsarearbitrarily minethemeaningofthesentence.Shelooksupthefirst
relatedtotheirreferentsinthatthephonemicandortho- logogram(anabstractsymbol)inthedictionary,onlyto
graphiccharacteristicsofawordbearnorelationshipto find that its definitionis given by its relationsto addi-
thephysicalorfunctionalcharacteristicsoftheword’sref- tionalabstractsymbols.Todeterminethemeaningofthe
erent. An alternativeview is that linguistic meaning is firstsymbolinthedefinition,shelooksitupinthedic-
groundedinbodilyactivity(e.g.,Barsalou,1999;Fincher- tionaryonlytobefacedwithadditionalabstractsymbols.
Kiefer, 2001;Glenberg, 1997;Glenberg & Robertson, Nomatterhowmanyoftheseabstractsymbolssherelates
1999, 2000;Lakoff, 1987; McNeill,1992;Stanfield & tooneanother,sheisnevergoingtodeterminethemean-
Zwaan, 2001).Here, we reporta new phenomenonthat ingofthesentence.Thelessonisthattheabstractsymbols
discriminatesbetweentheseapproaches.Wedemonstrate oflanguagemustbegrounded,ormapped,totheworldif
thatmerelycomprehendingasentencethatimpliesaction theyare to conveymeaning.Butthereare goodreasons
inonedirection(e.g.,“Closethedrawer”impliesaction forbelievingthatifonehasonlyabstractsymbolsatone’s
awayfromthebody)interfereswithrealactionintheop- disposal,determinationofthecorrectmappingisimpos-
positedirection(e.g.,movementtowardthebody).These sible(Lakoff,1987).
dataareconsistentwiththeclaimthatlanguagecompre- In contrasttomeaningasanabstractsymbolsystem,
hensionisgroundedinbodilyaction,andtheyareincon- considerthepossibilitythatmeaningisembodied—that
sistentwithabstractsymboltheoriesofmeaning. is,thatitderivesfromthebiomechanicalnatureofbodies
Whereassomefeaturesofthelinguisticsignalappear andperceptualsystems(Glenberg,1997;Lakoff,1987).
tobeconsistentwiththeabstractsymbolview(e.g.,words Onesuchaccountisprovidedbytheindexicalhypothesis
(IH), which proposes that meaning is based on action
(Glenberg & Robertson,1999,2000).Forexample,con-
ThisworkwaspartiallysupportedbyaUniversityofWisconsinVilas siderhowasituation(e.g.,a roomwithachair)couldbe
AssociateAwardtothefirstauthorandaNationalScienceFoundation
meaningfulto an animal.By hypothesis,the meaningof
GraduateFellowshiptothesecondauthor.WethankSandraJapuntich,
MichelleLenzen,AdamNelson,EricaRamirez,andDonaldTeaguefor thesituationconsistsofthesetofactionsavailabletothe
theireffortsindatacollectionandfortheirdiscussionsaboutthesere- animal in the situation. The set of actionsresults from
sults.Inaddition,ImmanualBarshi,AngelFernandez,WillLangston, meshing(i.e.,smoothlyintegrating)affordancestoaccom-
andLarryShapirohelpedussharpenourideas.Correspondenceshould
plishaction-basedgoals.Affordancesare potentialinter-
beaddressedtoA.M.Glenberg,DepartmentofPsychology,University
actionsbetweenbodiesandobjects(Gibson,1979;Tucker
ofWisconsin,1202WestJohnsonStreet,Madison,WI53706(e-mail:
glenberg@facstaff.wisc.edu). &Ellis,1998).Thus,a chairaffordssittingforadulthu-
Copyright2002PsychonomicSociety,Inc. 558

GROUNDING LANGUAGE INACTION 559
mans,butnotformiceorelephants,whohavethewrong independentvariable,impliedsentencedirection(toward/
sortsofbodiestositinanordinarychair.Achairalsoaf- away),wasmanipulatedforthesensiblesentences.Thus,
fordsstanding-onforthehuman.Ifthehumanhasthegoal toward sentences,such as “Open the drawer” and “Put
ofchangingalightbulbinaceilingfixture,themeaning yourfingerunderyournose,”impliedactiontowardthe
ofthesituationarisesfrommeshingtheaffordancesofa body. Away sentences,such as “Close the drawer” and
lightbulb(itcanbeheldinthehand)withtheaffordances “Putyourfingerunderthefaucet,”impliedactionaway
of the chair(it can bestoodon to raise the body)to ac- fromthebody.Thenonsensesentences,suchas“Boilthe
complishthegoalofchangingthebulb. air,” did not seem to implyany direction.Note that the
AccordingtotheIH,threeprocessestransformwords participantswereneverinstructedtoconsidertheimplied
and syntaxinto an action-based meaning.First, words direction;theirtaskwasmerelytojudgesensibility.The
andphrasesareindexedormappedtoperceptualsymbols actual response direction (yes-is-near/yes-is-far) was
(Barsalou,1999;Stanfield& Zwaan, 2001).Unlikeab- manipulatedbyusingaspeciallyconstructedbuttonbox
stract symbols,perceptualsymbolsare modal and non- approximately2831836cm.Theboxwasheldinthe
arbitrary. They are based on thebrain states underlying lap,withthelongestdimensionprojectingoutwardfrom
theperceptionofthereferent.Second,affordancesarede- thebody.Threecriticalresponsebuttonswerearrayedon
rivedfromtheperceptualsymbols(Glenberg&Robert- the top surface (two other buttonswere nonfunctional),
son,2000;Kaschak&Glenberg,2000).Unlikethecase andtheydifferedindistancefromthebody:near,middle,
witharbitrarysymbols,new affordancescanbederived and far. Visual presentation of a sentencewas initiated
fromperceptualsymbolsbecauseperceptualsymbolsare bypressingthemiddlebuttonwiththeindexfingerofthe
notarbitrarilyrelatedtotheirreferents.Forexample,one right hand.The sentencewas displayedon a computer
canjudgethatthesentence,“Hangthecoatontheupright monitoruntilthemiddlebuttonwasreleased.Intheyes-
vacuumcleaner”issensible,becauseonecanderivefrom is-farcondition,theparticipantsrespondedthatthesen-
the perceptualsymbolof the vacuumcleanerthe affor- tencewassensiblebymovingfromthemiddlebuttonto
dancesthatallowittobeusedas a coatrack.Similarly, thefarbutton—thatis,theymovedawayfromthebody
onecanjudgethatthesentence“Hangthecoatontheup- to respond yes. In this condition, the participants re-
rightcup”isnotsensibleinmostcontexts,becausecups spondednobymovingfromthemiddlebuttontothenear
do not usually have the proper affordances to serve as button. The yes-is-near condition had the reverse as-
coatracks.Notethatneitherofthesejudgmentscouldbe signment:Theparticipantsmovedtowardthebodytore-
basedonexplicitpreviouslearning(unlessyouhadtried spondyes.Themajordependentvariablewasthetimebe-
tohangacoatonacupandyoufailed),norcouldtheybe tween presentation of the sentence and release of the
basedonabstractsymbols;becauseabstractsymbolsare middlebutton(tomovetothenearorthefarbutton),cor-
arbitrarily related to their referents, one cannot derive respondingto the time to read and understandthe sen-
newaffordancesfromthem. tenceandtobegintomakethesensibilityresponse.
ThethirdprocessspecifiedbytheIHisthataffordances AccordingtotheIH,meaningisaction-based:Under-
aremeshedundertheguidanceofsyntacticconstructions standingatowardsentencerequiresmeshingaffordances
(Kaschak & Glenberg,2000).As will be described in (e.g.,ofadrawerandtheactionofopening),resultingin
greaterdetaillater,thegrammaticalformofthesentence asimulationofactionstowardthebody,whereasunder-
directs a cognitivesimulationthat combines,for exam- standinganawaysentenceresultsinasimulationofac-
ple,theaffordancesofanuprightvacuumcleanerandof tionsmovingawayfrom thebody.If thissimulationre-
a coatto accomplishthegoalof hangingupthecoat.If quires the same neural systems as the planning and
themeshedsetofaffordancescorrespondstoadoableac- guidanceofrealaction,understandingatowardsentence
tion,theutteranceisunderstood.Iftheaffordancesdonot shouldinterferewithmakingamovementawayfromthe
meshinawaythatcanguideaction(e.g.,howcouldone bodyto indicateyes (yes-is-far), and understanding an
hanga coatona cup?),understandingis incomplete,or awaysentenceshouldinterferewithmakingamovement
thesentenceisjudgednonsensical,eventhoughallofthe towardthebody(yes-is-near).Becausewedidnotcontrol
words and syntacticrelationsmay be commonplace.In forthefinedetailsofthesentences(e.g.,length,frequency
short,theIHproposesthatlanguageismademeaningful of words) or for any intrinsicdifferences in ease of re-
by cognitively simulating the actions implied by sen- sponsedirection,thepredictionwasforastatisticalinter-
tences.Theexperimentsthatwillbereportednextwere actionbetweenimpliedsentencedirectionandactualre-
designedto provide convincingevidencefor this claim sponsedirection.Thisinteractionwill be referred to as
bydemonstratingthattheactionsimpliedbya sentence theaction–sentencecompatibilityeffect(ACE).
caninterferewithrealaction. Wealsomanipulatedthesentencetype.Halfofthe80
sensiblesentencepairs(i.e.,40toward/awaypairs)werein
EXPERIMENT1 theimperative,suchastheexamplesabove.Theotherhalf
ofthesensiblesentencepairsdescribedatypeoftransfer.
Participantswerepresentedwithaseriesofsensibleand The concretetransfer pairs (20 toward/away pairs) de-
nonsensesentences,andtheywereaskedtodetermineas scribed transfer of a physicalobjectbetween“you”and
quicklyaspossiblewhethereachsentencemadesense.One anotherperson.Halfoftheseusedthedouble-objectcon-

560 GLENBERGANDKASCHAK
struction(e.g.,“Courtneyhandedyouthenotebook/You presentationofthesentenceandwhentheparticipantre-
handedCourtneythenotebook”)andhalfusedthedative leasedthemiddlebutton).Toreducepracticeeffects,the
form (e.g.,“Andydeliveredthepizzatoyou/You deliv- firstblockof16trialswasdiscardedforboththeyes-is-
eredthepizzatoAndy”). The 20abstracttransferpairs nearandtheyes-is-farconditions.Toreducetheeffectof
described a nonphysicaltransfer, such as “Liz told you outliers,for each participant, for each of the 12 condi-
thestory/YoutoldLizthestory”and“Thepolicemanra- tions(defined by combinations of two response direc-
dioedthemessagetoyou/Youradioedthemessagetothe tions,twoimpliedsentencedirections,andthreesentence
policeman.” types),boththefastestandtheslowestreadingtimeswere
discarded.Themeanoftheremainingreadingtimesisre-
Method ferredtoasthetrimmedmeanreadingtime.Inaddition,
The44right-handed, nativeEnglish-speaking participants were 9participantswereeliminatedbecauseoffailuretomain-
recruitedfromintroductorypsychologyclassesattheUniversityof taina constanterrorrateacrossconditions—thatis,the
Wisconsin,Madison,andearnedextracreditpointsforparticipation. within-subjectsrangeintheirerrorrateswasatleast.5.
Eachparticipant judged the sensibility of 160 sentences, half of (Theresultsoftheanalysesweresubstantiallythesame
whichwereintendedtobesensibleandhalfofwhichwereintended
withandwithoutthese9participants.)AType1errorrate
tobenonsense.Eachparticipantwasinitiallyrandomlyassignedto
of.05wasadopted.
theyes-is-near oryes-is-far condition. Midwaythroughtheexper-
iment,theparticipantwasinstructedtoreversetheassignmentofre- Thedataofmajorinterestare illustratedinFigure1.
sponsetobuttonandwasgivenadditionalpracticewiththenewas- Theinteractionbetweenresponsedirectionandimplied
signment.Ofthesensiblesentences,40wererandomlychosenfrom sentence direction—that is, the ACE—is significant
pairs of toward/awayimperative sentences, 20 werechosen from [F(1,34) 5 7.75,MS 5 47,013]. Although the effect
pairsoftoward/awayconcretetransfersentences,and20werecho- e
seems to be strongerfor the two types of transfer sen-
senfrompairsoftoward/awayabstracttransfersentences.Forboth
tences,as comparedwith the imperativesentences,the
the concrete andthe abstract transfer sentences, half were inthe
double-object form,andhalfwereinthedativeform.Fortyofthe three-factor interaction was not significant (F), 1).1
nonsensesentenceswereinanimperativeformbutdescribedactions ThisresultconfirmsthepredictionfromtheIHandisin-
thatcould not(except under somehighly metaphorical readings) consistentwithabstractsymboltheoriesofmeaning.In
takeplace.Theother40nonsensesentences wereindouble-object fact,theresultisquiteamazing:Merelyunderstandinga
anddativeforms.Someexamplesare“YougavetheearringSusan”
sentencecan facilitate or interfere with a physical re-
and“Joesangthecardstoyou.”Thepresentation ofthe160sen-
sponse.
tences wasdivided into 10blocks of16sentences, inwhicheach
Therewereseveralothersignificanteffectsintheanaly-
blockcontained arandommixof8nonsense sentences, 4impera-
tivesentences(2towardand2away),2concretetransfersentences sesofthetrimmedmeanreadingtimes.Therewasalarge
(1towardand1away),and2abstracttransfer sentences (1toward main effect of sentencetype[F(2,68) 5 72.41,MS 5
e
and1away). 111,207],reflectingthefact that the shorterimperative
sentenceswere read muchfaster thanthelongertransfer
Results sentences.Therewasalsoasignificantinteractionbetween
Analyseswereconductedontheproportionofcorrect sentencedirectionand sentencetype[F(2,68) 5 3.97,
judgments,aswellasonthereadingtimes(timebetween MS 563,887].Thatis,theawaysentenceswerereadmore
e
Figure1.DatafromExperiment1illustratingtheaction–sentencecompatibilityeffect(thatis,theinteractionbetweenimpliedsen-
tencedirectionandactualresponsedirection)forimperativesentences,concretetransfersentences,andabstracttransfersentences.

GROUNDING LANGUAGE INACTION 561
quicklythanthetowardsentencesforboththeimperative index finger was poised over the no button(either far
andtheconcretetransfersentences,buttheoppositeheld fromorneartothebody).Thepredictionderivedfromthe
fortheabstracttransfersentences. IHisthattheACEwillbeeliminatedinthisexperiment
becausethereisnorelevantinterferingactionwhenthe
Discussion responseismade.
Severalaspectsoftheresultsarenotable.First,theACE
is strong evidence that at least some language under- Method
standingtaps into an action-based system. Second,we Therewere70participantsinExperiment2Aand72participants
have demonstrated theACE for multiplesentencecon- inExperiment2BfromthesamesourceasinExperiment1.Thepar-
ticipantswererandomlyassignedtoExperiment2Aor2Bafterre-
structions—namely,imperativesentences,double-object
portingtothelaboratory.Aftersigningaconsentform,thepartici-
sentences,and dative constructions.Third, the ACE is
pants were instructed about the operation ofthebutton box and
found for sentences that describe concreteactions(the
practicedtheappropriate responsemethod.AsinExperiment1,all
imperativeandtheconcretetransfersentences),aswell theparticipants judged160sentences,consistingof10blocksof16
asforsentencesthatdescribemoreabstractactions(the sentences.
abstracttransfersentences).Thisfindingisimportantfor
ruling out an alternativeexplanation of the effect. Ac- Results
cordingto the IH, understanding a sentencecallsupon Thefirstblockof16trialswastreatedaspracticeand
the same cognitivemechanisms as those used in plan- was discarded.No participant showed a range of error
ningandtakingaction.Hence,whentheimplieddirec- ratesgreaterthanorequalto.5,andhencenonewaselim-
tion of the sentencecontrastswith the actualresponse inated. Trimmed mean reading times were computed
direction,thereisinterference.Thealternativeisthatun- from the remainingtrials, and the data of most interest
derstanding reflects the manipulation of abstract sym- are presentedin Figure2 (for Experiment2A) and Fig-
bols.However,onceasentenceisunderstood,sentences ure3(forExperiment2B).
that imply action are translated into an action pattern, Experiment2A.TheACEinteractionofimpliedsen-
anditisthispostunderstandingtranslationthatinterferes tencedirectionandactualresponsedirectionwassignifi-
with the response.This alternativecan account for the
cant[F(1,68)53.72,MS 591,069].Theonlyothersig-
e
datafromtheimperativeandconcretetransfersentences. nificantfindingforthereadingtimeswasamaineffectof
Thesesentenceseitherdemandactions(imperatives)or sentencetype[F(2,68)5 191.71,MS 5 46,871],indi-
e
describeactions(concretetransfer)thatmaybecontrary catingthat the shorterimperative sentenceswere read
to the actionsneededto make the sensibilityresponse. more quicklythanthe longertransfer sentences.There
The alternative cannot account for the ACE observed weretwomaineffectsintheanalysisoferrorrates.First,
withtheabstracttransfersentences.Forthesesentences, therewerefewererrorsonthetowardsentences(4%)than
the actionsrequiredto effect the transfer (e.g., talking, on the away sentences [7%; F(1,68) 5 6.99, MS 5
e
singing,radioing)do not directly contrast with the ac- 76.87].Second,therewerefewererrorsfortheimperative
tionsneededtomaketheresponse(movingthearmand sentences(4%)thanfortheconcrete(6.5%)ortheabstract
handtotheyesbutton).Thus,eveniftherewereapost-
(7%)transfersentences[F(2,136)510.99,MS 538.87].
e
understanding translation into an action pattern, there Experiment2B.Therewasverylittleevidenceforan
wouldbenoreasontosuspectthatthatpatternwouldin-
ACEinteraction[F(1,70)50.20,MS 543,935].Thus,
e
terferewiththemanualresponse. the contrastbetweentheresults of Experiments2A and
2Bindicatethattheinterferencearisesfromaction,rather
EXPERIMENTS2AAND 2B than from the spatial locationof the response buttons.
Severalothereffectsweresignificantintheanalysisof
Experiment2Awasdesignedtoreplicateandmodestly trimmedmeanreadingtimesanderrorrates.Fortheread-
extendthemajoreffects from Experiment1.In Experi- ingtimes,therewasamaineffectofimpliedsentencedi-
ment2A,theresponsedirectionvariablewasmanipulated rection,inthattowardsentences(trimmedmeanreading
betweensubjects.Inaddition,theparticipantsresponded timeof1,742msec)werereadfasterthanawaysentences
withtheirlefthands.Thus,wecoulddeterminewhether [1,800msec; F(1,70)5 8.27,MS 5 43,935].Also,the
e
theACEreflectsaction-planningspecificforthedomi- imperative sentences were read much faster than the
nanthandintheseright-handedsubjects.Otherwise,the longertransfer sentences [F(2,140) 5 425.66,MS 5
e
experimentwassubstantiallyidenticaltoExperiment1. 25,902].Finally,therewasasignificantinteractionofsen-
Experiment2Bwasdesignedtotestaspatiallocation tence direction and sentence type [F(2,140) 5 3.88,
alternativetotheIH.Confoundedwiththeactionsrequired MS 523,299].Therewerecorrespondingeffectsinthe
e
intheyes-is-nearandyes-is-farconditions,however,was errorratesthatwerepositivelycorrelatedwiththereading
locationoftheyesresponsebuttons:closerorfartherfrom times,precludingspeed–accuracytradeoffs.Therewasa
thebody,respectively.In Experiment2B,theparticipant main effect of implied sentencedirectionin that there
intheyes-is-nearoryes-is-farconditiondidnotmovethe werefewererrorsontowardsentences(6%)thanonaway
hand.Instead,theleftindexfingerwaspoisedovertheyes sentences[7%;F(1,70)53.65,MS 539.64].Therewas
e
button(eitherneartoorfarfromthebody),andtheright amaineffectofsentencetype,sothattherewerefewerer-

562 GLENBERGANDKASCHAK
Figure2.DatafromExperiment2Aillustratingtheaction–sentencecompatibilityeffectforimperativesentences,concretetrans-
fersentences,andabstracttransfersentences.
rorsontheimperativesentences(5%)thanontheconcrete detailedactionplanningatthelevelofparticularmuscles.
(7%)ortheabstract(7%)transfersentences[F(2,140)5 Third,thecontrastbetweenExperiments2Aand2Bindi-
4.76,MS 541.10].Finally,therewasaninteractionbe- catethattheACEdependsonaction,andnotsolelyonspa-
e
tweenthesefactors,inthatthedifferencebetweentheto- tiallocationoftheresponses.
wardandtheawayimperativesentences(4%)wasgreater
thanthecorrespondingdifferencesfortheconcrete(0.5%) GENERAL DISCUSSION
and theabstract (2.5%)transfer sentences[F(2,140)5
4.23,MS 538.78]. TheACEisconsistentwiththepredictionderivedfrom
e
the IH and supports the notion that language under-
Discussion standingisgroundedinbodilyaction.Thatis,themean-
TheresultsfromExperiments2Aand2Baccomplished ingofasentenceisgivenbyanunderstandingof(1)how
threegoals.First, theydemonstratedreplicabilityof the the actions described by the sentence can be accom-
ACE.Second,theyextendedthephenomenontoabetween- plishedor(2)howthesentencechangesthepossibilities
subjectsdesigninwhichtheparticipantsrespondedusing foraction(aswillbedescribedlater).TheACEdemon-
thenondominanthand.Thus,theACEisunlikelytoreflect stratesthatthisdescriptionoflanguageunderstandingis
Figure3.DatafromExperiment2B.Inthisexperiment,respondingdidnotrequiremovementtotheresponsebuttons,andtheaction–
sentencecompatibilityeffectwaseliminated.

GROUNDING LANGUAGE INACTION 563
notmetaphorical—thatis,itisnotsimplyawaytodescribe How are theseconstructional meaningslearned?It is
understanding.Instead,realbodilyactionisattherootof likely that young children learn the actionsassociated
meaningconveyedbylanguage. withfrequentlyheardverbs,suchas“togive,”bybeing
Thisrestofthediscussionwillbefocusedontwotop- rewardedforcorrectresponseswhenaparentmakessuch
ics.First,wewilldiscusshowtheIHproposesthatafford- utterances as “Give me the bottle” (Tomasello, 2000).
ances are combined with grammatical information to The actions then become associated with the double-
resultinameshedorintegratedunderstanding.Thisdis- objectconstructionbecauseofthefrequentpairingofthe
cussionwillleadtoanexplanationfortheACEfoundwith verb “to give”and thedouble-objectconstruction, as in
the abstract transfer sentences.Second,we will briefly “YougiveLizthetoy.”Thus,thedoubleobjectconstruc-
discusswhethertheclaimthatlanguageisgroundedinac- tioncomestobetreatedasaninstructiontomeshaffor-
tioncanbeextendedtoformsoflanguagethatseemfarre- dancesofthereferentsof“you,”“Liz,”and“toy”inorder
movedfromaction. toaccomplishthegoalofgiving.Overdevelopment,the
Toreview,theIHproposesthatwordsandphrasesare double-object instructions for meshing are appliedto
indexed to analogical perceptual symbols (Barsalou, otheractionsthatcan effect transfer, such as “to hand,”
1999)basedonthebrainstatesunderlyingtheperception “tosend,”“tobicycle,”and“tocrutch.”Thefinalstepis
ofthereferent.Second,affordancesarederivedfromthe toapplythedouble-objectinstructionswhenthetransfer
perceptualsymbols.Third,affordancesaremeshedunder isnotofaphysicalobjectbutofinformation,asin“You
the guidance of syntactic constructions (Kaschak & told Liz the story.” That is, we come to understandthe
Glenberg,2000).Meshing is the smoothintegrationor sentenceasaphysicalmovementfrom“you”to“Liz.”To
combinationofactionoractionplans.Thus,onecanlit- sayitdifferently,overthecourseoflearningtheEnglish
erallycombinetheactionsofsittinginachairandeating double-object construction,we learn to treat the con-
(those actionsmesh), whereas one cannotcombinethe structionasaninstructiontosimulatealiteraltransferof
actionsofsittinginachairandjumpingrope. anobjectfromoneentitytoanotherevenwhentheobject
Howdoesgrammaticalinformationguidethemeshing beingtransferredisnotaphysicalobject.Thissimulation
ofaffordances?Accordingtoconstructiongrammarians isconsistentwiththeclaimthatpeopleunderstandcom-
(e.g.,Goldberg,1995;Kay&Fillmore,1999;Michaelis& municationas a typeof transfer in which words act as
Lambrecht,1996),constructions2carryageneralmean- containersofinformation(Lakoff,1987).
ingthatisnotdependentontheparticularlexicalitemsin Whatisthescopeofthisanalysis?Clearly,ourdatail-
thesentence.Forexample,thedouble-objectconstruction, lustrateanaction-basedunderstandingforonlyalimited
“Subject–verb–object –object ” carries the meaning setofEnglishconstructions.Furthermore,theconstruc-
1 2
thatthesubjecttransfersobject toobject .Thatthesen- tionswe examined are closely associated with explicit
2 1
tenceformcarriesmeaningcanbedemonstratedbyusing action.Even the abstract transfer sentencesare not far
innovativedenominalverbs—thatis,verbsmadeupanew removed from literal action.Althoughwe have not at-
fromnouns(Kaschak&Glenberg,2000).Forexample, tempteda formaloranexperimentalanalysisofhowto
uponwatchinganinjuredwomanwhoishobblingpasta extend the scope of the IH, we providethree sketches
soccerfieldreturnanerrantballtothegoalie,onemight thatillustratehowitmaybepossibletodoso.
remark,“Thewomancrutchedthegoalietheball.”Inthis Considerfirsthowwemightunderstandsuchsentences
sentence,theinnovativedenominalverb“tocrutch”seems as“Thedogisgrowling”or“Thatisabeautifulsunset.”
tomean“useacrutchtotransferanobject.”However,the Weproposethatlanguageisusedandunderstoodinrich
meaningmustbecomingfromtheconstruction,because contextsandthat,inthoserichcontexts,somestatements
theverb“tocrutch”hasno(dictionary)meaning.Inthis areunderstoodasprovidingnewperspectives—thatis,as
example,theconstructioncoercesanewperspectiveon highlightingnewaffordancesforaction.Thus,whiletak-
“crutch”fromsomethingusedtosupportthebodytoanin- ingawalkinaneighborhood,onepersonmayremarkthat
strumentoftransfer.Importantly,thiscoercionwillbesuc- anapproachingdogisquitefriendly.Acompanionmight
cessfulonlyiftheobject(thecrutch,inthiscase)hasthe note,“The dog is growling.” Thisstatementis meantto
properaffordancestoeffect thetransferof object (Ka- draw attention to a new aspect of the situation (i.e., a
2
schak&Glenberg,2000).Forexample,itwouldbediffi- changingperspective),therebyrevealingnewaffordances.
culttounderstandhowawomanintheparkwhohadjust Thesenewaffordanceschangethepossibilitiesforaction
finishedeatingalunchofhard-boiledeggsmight“egg- and,thus,changethemeaningofthesituation.Asimilar
shell”thegoalietheball:Ordinaryeggshellsdonothave analysisappliestosuchsentencesas“Thatisabeautiful
therightaffordancestoeffectthetransferofsoccerballs. sunset.”Thestatementismeanttochangethemeaningof
Thus, accordingto theIH, the meaningassociatedwith asituationbycallingattentiontoanaffordance:Thesun-
theconstruction(e.g.,transfer)isusedtoguidethemesh- setaffordslookingat,andactingonthisaffordanceresults
ingofaffordancesderivedfromtheperceptualsymbols. inthegoalofapleasurableexperience.
When the affordancescan be smoothlycombined(e.g., As a second sketch, consider the notion of cause.
wecanenvisionhowahumancanuseacrutchtotrans- Causalreasoningisimportantforoureverydayandscien-
ferasoccerballtoagoalie),thesentenceisunderstood. tificunderstandingofthephysicalworld,forourunder-

564 GLENBERGANDKASCHAK
standingofsocialrelations,andforourunderstandingof andtheunderlyinghypothesis,thedirectoridentifiedwith
discourse(Keenan,Baillet,&Brown,1984;Singer,1994; thesubstance(“WhenIcomedown...”)andusedhisarm
vandenBroek,1994).Manyanalysesofcausalreasoning gesturesto simulatechangesintemperature.Ochs etal.
and causallanguagerevolvearoundabstractideas,what notedthat thissort of explicitbodilyidentificationwas
NovickandCheng(inpress)refer toas“purelycovaria- usedjustwhenthescientistswerehavingadifficulttime
tional”approaches,inwhichtheinferenceofcausalityis understandinga new hypothesis.Similarly, Roth(1999)
basedonananalysisofthecovariationofevents.Incon- notedthat studentsin a highschoolphysicslaboratory
trast,a simple,embodiedanalysisof causal languageis groundedtheirlanguageaboutthedynamicsofachaotic
possible.Infantsmaylearnaboutthecausalpoweroftheir systembyusingtheirbodies(e.g.,movingachinbackand
ownactionsearlyindevelopment(Piaget,1954).Forex- forthtocorrespondtochangesinthesystem).Thepoint
ample,infantslearnhowadjustingtheirsensoryappara- ofthissketchistodemonstratethatbothprofessionalsci-
tus brings new views of the world (O’Regan & Noe, entistsand naivestudentsattemptto ground language
2001).Similarly,frommovingbodypartswithsufficient aboutabstractphenomenainbodilyexperience.
force,infantscanlearnhowforcefulchangesinbodyparts In summary, ourresults demonstrate that the under-
canaffectboththeirbodiesandotherobjects(Meltzoff& standingofimperative,double-object,anddativeconstruc-
Moore,1997).Fromthesebasicexperience,infantslearn tionsis groundedinaction.Giventhatlanguagealmost
toconceptualizecausesastheapplicationofabodilyforce certainlyarosetofacilitatecoordinationofaction,itisnot
toeffectachangeorresistachange.Furthermore,wepro- surprisingthatthereisanobservableremnantofthathis-
posethatthisnotionofcauseisusedtogroundcausallan- tory. Theresultsalso raise the intriguingpossibilitythat
guage.That is, even as adults,we understandlanguage much, if not all, languagecomprehension is similarly
aboutphysical,social,and psychological causation in grounded.Althoughsubstantialworkneedstobedoneto
terms of thepushesand pullsof ourbodilyexperience. securethatpossibility,thatworkmaywellberewardedby
This proposalis consistent with the force dynamics an accountof languageandmeaningfirmly anchoredin
analysisofcausallanguagedevelopedbyTalmy (1988). humanexperience.
Accordingto Talmy,causalconstructionsportraycausal
eventsas simplecontrastsbetweenagonistsandantago- REFERENCES
nists,actingagainstoneanothertoproducechangeorsta-
Barsalou,L.W.(1999).Perceptualsymbolssystems.Behavioral&
sis.Thus,onTalmy’sanalysis,thesentence“Theshedfell
BrainSciences,22,577-660.
becauseof the wind blowingon it” portrays the weaker Burgess,C.,& Lund,K.(1997).Modellingparsingconstraintswith
agonist,theshed,succumbingtothestrongerantagonist, high-dimensionalcontextspace.Language&CognitiveProcesses,
thewind.Onourembodiedanalysis,weproposethatpeo- 12,177-210.
pleconceptualizethewind as pushingagainstthe shed,
Chomsky,N.(1980).Rulesandrepresentations.NewYork:Columbia
UniversityPress.
muchasonemightpushoverahouseofcards.OnTalmy’s Fillmore,C.J.,Kay,P.,&O’Connor,M.C.(1988).Regularityandid-
analysis,thesentence“Thespeakerrefusedtostopdespite iomaticityingrammaticalconstructions:Thecaseofletalone.Lan-
thefactthattimeranout”portraysastrongeragonist(the guage,64,501-538.
speaker)overcomingthe weaker antagonist, the social
Fincher-Kiefer,R.(2001).Perceptualcomponentsofsituationmodels.
Memory&Cognition,29,336-343.
normofstoppingwhentimerunsout.Weproposethatun-
Fodor,J.(2000).Theminddoesn’tworkthatway.Cambridge,MA:MIT
derstandingthissortofsituationrequiresanembodiedno-
Press.
tionofforcefulactionakintopushing(bythesocialnorm) Gibson,J.J.(1979).Theecologicalapproachtovisualperception.
andresistingthepush.Thisanalysispresupposesatypeof Boston:HoughtonMifflin.
identificationorprojectionprocess.Thatis,thelanguage
Glenberg,A.M.(1997).Whatmemoryisfor.Behavioral&BrainSci-
ences,20,1-55.
comprehender can projectonto the wind (or the social Glenberg,A.M.,& Robertson,D.A.(1999).Indexicalunderstand-
norm)hisorherexperiencesofforcefulaction. ingofinstructions.DiscourseProcesses,28,1-26.
ThefinalsketchisbasedonresearchreportedbyOchs, Glenberg,A.M.,&Robertson,D.A.(2000).Symbolgroundingand
Gonzales,and Jacoby(1996).They studiedinteractions meaning:Acomparisonofhigh-dimensionalandembodiedtheories
ofmeaning.JournalofMemory&Language,43,379-401.
amongscientistsparticipating in a high-energyphysics
Goldberg,A.E.(1995).Aconstructiongrammarapproachtoargu-
laboratory.Thephysicists’discussionswere abouthow
mentstructure.Chicago:UniversityofChicagoPress.
changesinthetemperatureofasubstanceresultinphase Harnad,S.(1990).Thesymbolgroundingproblem.PhysicaD,42,
transitionsamongthreemagneticstates,oneofwhichis 335-346.
termedadomainstate.Ochsetal.reportedthatwhiletry-
Kaschak,M.P.,& Glenberg,A.M.(2000).Constructingmeaning:
Theroleofaffordancesandgrammaticalconstructionsinsentence
ingtounderstandtherelationsdepictedinagraphofmag-
comprehension.JournalofMemory&Language,43,508-529.
neticfield strength(y-axis)asa functionoftemperature Kay,P.,& Fillmore,C.J.(1999).Grammaticalconstructionsandlin-
(x-axis), the laboratory director gesturally simulated guisticgeneralizations:TheWhat’sXdoingY?construction.Lan-
changesin temperature by movinghis handacross the guage,75,1-33.
Keenan,J.M.,Baillet,S.D.,&Brown,P.(1984).Theeffectsofcausal
graph parallel to the x-axis. While doing so he said,
cohesiononcomprehensionandmemory.JournalofVerbalLearning
“WhenIcomedown[intemperature]I’minthedomain
&VerbalBehavior,23,115-126.
state.”Apparently,inattemptingtounderstandthegraph Kintsch,W.(1988).Theroleofknowledgeindiscoursecomprehen-

GROUNDING LANGUAGE INACTION 565
sion:Aconstruction-integrationmodel.PsychologicalReview,95, tationderivedfromverbalcontextonpicturerecognition.Psycholog-
163-182. icalScience,12,153-156.
Lakoff,G.(1987).Women,fire,anddangerousthings:Whatcategories Talmy,L.(1988).Forcedynamicsinlanguageandcognition.Cognitive
revealaboutthemind.Chicago:UniversityofChicagoPress. Science,12,49-100.
McNeill,D.(1992).Handandmind.Chicago:UniversityofChicago Tomasello,M.(2000).Doyoungchildrenhaveadultsyntacticcom-
Press. petence?Cognition,74,209-253.
Meltzoff,A.N.,&Moore,M.K.(1997).Explainingfacialimitation: Tucker,M.,& Ellis,R.(1998).Ontherelationsbetweenseenobjects
Atheoreticalmodel.EarlyDevelopment&Parenting,6,179-192. andcomponentsofpotentialactions.JournalofExperimentalPsy-
Michaelis,L.,& Lambrecht,K.(1996).Towardaconstruction-based chology:HumanPerception&Performance,24,830-846.
modeloflanguagefunction:Thecaseofnominalextraposition.Lan- vandenBroek,P.(1994).Comprehensionandmemoryofnarrative
guage,72,215-247. texts:Inferencesandcoherence.InM.A.Gernsbacher(Ed.),Hand-
Novick,L.R.,& Cheng,P.W.(inpress).Assessinginteractivecausal bookofpsycholinguistics(pp.539-589).SanDiego:AcademicPress.
influence.PsychologicalReview.
Ochs,E.,Gonzales,P.,& Jacoby,S.(1996).“WhenIcomedownI’m NOTES
inthedomainstate”:Grammarandgraphicrepresentationinthein-
terpretiveactivityofphysicists.InE.Ochs,E.A.Schegloff,&S.A. 1.Inaseparateexperimentnotreportedhere,weusedonlytheimper-
Thompson(Eds.),Interactionandgrammar(pp.328-369).NewYork: ativesentencesandmanipulatedresponsedirectionbetweensubjects.The
CambridgeUniversityPress. ACEwassignificant[F(1,54)512.33,MS 511,251].
e
O’Regan,J.K.,& Noe,A.(2001).Asensorimotoraccountofvision 2.Ingeneral,aconstructionisapairingofaformandameaning,in
andvisualconsciousness.Behavioral&BrainSciences,24,939- whichthemeaningcannotbededucedfromthecomponentsoftheform
1031. (e.g.,Goldberg,1995).Thus,monomorphemicwords(e.g.,“book”)and
Piaget,J.(1954).Theconstructionofrealityinthechild.NewYork: somephrases(e.g.,“allofasudden”and“byandlarge”;seeFillmore,
BasicBooks. Kay,&O’Connor,1988)areconstructions,inthatthemeaningcannotbe
Pinker,S.(1994).Thelanguageinstinct.NewYork:HarperCollins. deducedfromtheletters,individualsounds,orindividualwords.Here,we
Roth,W.-M.(1999).Discourseandagencyinschoolsciencelaborato- restrictthemeaningofconstructiontoverb-argumentconstructions,such
ries.DiscourseProcesses,28,27-60. asthedouble-objectconstruction,inwhichameaning(e.g.,transfer)is
Searle,J.R.(1980).Minds,brainsandprograms.Behavioral&Brain pairedwithasyntacticform(e.g.,theabstractformofthedoubleobject
Sciences,3,417-424. construction).
Singer,M.(1994).Discourseinferenceprocesses.InM.A.Gernsbacher
(Ed.),Handbookofpsycholinguistics(pp.479-517).SanDiego:Aca-
demicPress. (ManuscriptreceivedAugust3,2001;
Stanfield,R.A.,& Zwaan,R.A.(2001).Theeffectofimpliedorien- acceptedforpublicationNovember12,2001.)

## 引用

```

```
